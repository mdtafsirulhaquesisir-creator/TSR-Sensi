TSR Sensi — Android Studio project source

ফিচার:
- ছবির মতো ডার্ক/নিয়ন UI
- Aim Control এবং Device Fix টগল
- OPEN FREE FIRE চাপলে Free Fire ইনস্টল থাকলে চালু হবে
- OPEN FREE FIRE MAX চাপলে Free Fire MAX ইনস্টল থাকলে চালু হবে
- গেম ইনস্টল না থাকলে বার্তা দেখাবে

APK বানানোর নিয়ম:
1. কম্পিউটারে Android Studio ইনস্টল করুন।
2. Android Studio থেকে Open করে এই প্রজেক্ট ফোল্ডার নির্বাচন করুন।
3. Gradle sync শেষ হলে Build > Build APK(s) চাপুন।
4. APK সাধারণত app/build/outputs/apk/debug/app-debug.apk-এ পাবেন।

গুরুত্বপূর্ণ:
এই অ্যাপের টগলগুলো ডিজাইন/ডেমো UI—এগুলো Free Fire-এর আসল sensitivity, DPI, FPS বা game settings পরিবর্তন করে না। গেম খোলার জন্য Android package visibility/launcher intent ব্যবহার করা হয়েছে।
