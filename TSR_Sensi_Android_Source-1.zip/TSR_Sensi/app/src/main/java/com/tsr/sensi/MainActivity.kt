package com.tsr.sensi

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val bg = Color.rgb(3, 4, 10)
    private val cyan = Color.rgb(32, 239, 255)
    private val orange = Color.rgb(255, 157, 50)
    private val muted = Color.rgb(157, 169, 190)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        buildUi()
    }

    private fun rounded(color: Int, stroke: Int = Color.TRANSPARENT, radius: Float = 22f): GradientDrawable {
        return GradientDrawable().apply {
            setColor(color)
            cornerRadius = radius * resources.displayMetrics.density
            if (stroke != Color.TRANSPARENT) setStroke((1.5f * resources.displayMetrics.density).toInt(), stroke)
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun label(text: String, size: Float, color: Int, bold: Boolean = true): TextView =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            gravity = Gravity.CENTER
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    private fun buildUi() {
        val scroll = ScrollView(this).apply { setBackgroundColor(bg); isFillViewport = true }
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(15), dp(15), dp(15), dp(26))
            setBackgroundColor(bg)
        }
        scroll.addView(page)
        setContentView(scroll)

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val logout = label("➜ লগ আউট", 14f, Color.rgb(255, 92, 110)).apply {
            background = rounded(bg, Color.rgb(255, 92, 110), 30f)
            setPadding(dp(15), dp(10), dp(15), dp(10))
            setOnClickListener { Toast.makeText(this@MainActivity, "TSR Sensi", Toast.LENGTH_SHORT).show() }
        }
        val topup = label("🪙 TOPUP 💎", 14f, Color.rgb(255, 205, 55)).apply {
            background = rounded(bg, Color.rgb(255, 205, 55), 30f)
            setPadding(dp(15), dp(10), dp(15), dp(10))
            setOnClickListener { Toast.makeText(this@MainActivity, "Topup option শিগগিরই আসবে", Toast.LENGTH_SHORT).show() }
        }
        top.addView(logout)
        top.addView(View(this), LinearLayout.LayoutParams(0, dp(1), 1f))
        top.addView(topup)
        page.addView(top, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(24) })

        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(15), dp(12), dp(20))
            background = rounded(Color.rgb(5, 7, 15), cyan, 28f)
        }
        page.addView(panel, LinearLayout.LayoutParams(-1, -2))

        val brand = label("TSR SENSI", 34f, Color.rgb(20, 235, 190)).apply {
            letterSpacing = 0.08f
            background = rounded(Color.rgb(6, 8, 17), Color.rgb(92, 22, 58), 20f)
            setPadding(dp(5), dp(16), dp(5), dp(16))
        }
        panel.addView(brand, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(17) })

        addSection(panel, "AIM CONTROL")
        addToggleGrid(panel, listOf("70% HEADSHOT", "40% AIM FOV", "40% NO RECOIL", "120 FPS"))
        addSection(panel, "DEVICE FIX")
        addToggleGrid(panel, listOf("1400 DPI", "FIX REGEDIT", "PHONE NO LEG", "PHONE NO HEAD"))

        val freeFire = Button(this).apply {
            text = "⚡  OPEN FREE FIRE  🔥"
            textSize = 19f
            letterSpacing = 0.06f
            setTextColor(Color.BLACK)
            isAllCaps = false
            background = GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(Color.rgb(0, 232, 135), Color.rgb(30, 222, 255), Color.rgb(160, 66, 255))
            ).apply {
                cornerRadius = dp(24).toFloat()
                setStroke(dp(2), Color.WHITE)
            }
            setOnClickListener { launchGame("com.dts.freefireth", "Free Fire") }
        }
        panel.addView(freeFire, LinearLayout.LayoutParams(-1, dp(70)).apply {
            topMargin = dp(25)
            bottomMargin = dp(18)
        })

        val max = Button(this).apply {
            text = "⚡  OPEN FREE FIRE MAX  🔥"
            textSize = 18f
            letterSpacing = 0.045f
            setTextColor(Color.WHITE)
            isAllCaps = false
            background = GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(Color.rgb(0, 112, 255), Color.rgb(125, 25, 255), Color.rgb(224, 0, 240))
            ).apply {
                cornerRadius = dp(24).toFloat()
                setStroke(dp(2), Color.WHITE)
            }
            setOnClickListener { launchGame("com.dts.freefiremax", "Free Fire MAX") }
        }
        panel.addView(max, LinearLayout.LayoutParams(-1, dp(70)))
        page.addView(label("TSR Sensi • Game launcher", 12f, muted, false).apply {
            setPadding(0, dp(14), 0, 0)
        })
    }

    private fun addSection(parent: LinearLayout, text: String) {
        val title = label(text, 18f, orange).apply {
            letterSpacing = 0.14f
            background = rounded(Color.BLACK, orange, 9f)
            setPadding(dp(20), dp(9), dp(20), dp(9))
        }
        parent.addView(title, LinearLayout.LayoutParams(-2, -2).apply {
            gravity = Gravity.CENTER_HORIZONTAL
            topMargin = dp(2)
            bottomMargin = dp(16)
        })
    }

    private fun addToggleGrid(parent: LinearLayout, titles: List<String>) {
        for (i in titles.indices step 2) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            row.addView(toggleCard(titles[i]), LinearLayout.LayoutParams(0, dp(122), 1f).apply {
                marginEnd = dp(7)
                bottomMargin = dp(12)
            })
            row.addView(toggleCard(titles[i + 1]), LinearLayout.LayoutParams(0, dp(122), 1f).apply {
                marginStart = dp(7)
                bottomMargin = dp(12)
            })
            parent.addView(row)
        }
    }

    private fun toggleCard(title: String): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(6), dp(10), dp(6), dp(8))
            background = rounded(Color.rgb(6, 9, 18), Color.rgb(38, 48, 67), 20f)
        }
        card.addView(label(title, 13f, muted).apply {
            maxLines = 2
            letterSpacing = 0.015f
        })
        val sw = Switch(this).apply {
            text = ""
            showText = false
            scaleX = 0.92f
            scaleY = 0.92f
            buttonTintList = null
            setPadding(0, dp(7), 0, 0)
            contentDescription = title
        }
        card.addView(sw)
        return card
    }

    private fun launchGame(packageName: String, gameName: String) {
        val pm: PackageManager = packageManager
        val intent: Intent? = pm.getLaunchIntentForPackage(packageName)
        if (intent != null) {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            try {
                startActivity(intent)
            } catch (_: Exception) {
                Toast.makeText(this, "$gameName চালু করা যায়নি।", Toast.LENGTH_LONG).show()
            }
        } else {
            Toast.makeText(this, "$gameName ইনস্টল করা নেই। আগে Play Store থেকে ইনস্টল করুন।", Toast.LENGTH_LONG).show()
        }
    }
}
